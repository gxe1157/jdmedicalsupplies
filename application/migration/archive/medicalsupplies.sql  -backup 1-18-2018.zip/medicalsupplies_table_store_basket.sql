
-- --------------------------------------------------------

--
-- Table structure for table `store_basket`
--

CREATE TABLE `store_basket` (
  `id` int(11) NOT NULL,
  `session_id` varchar(64) NOT NULL,
  `item_title` varchar(255) NOT NULL,
  `price` decimal(7,2) NOT NULL,
  `tax` decimal(7,2) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` int(11) NOT NULL,
  `item_color` varchar(70) NOT NULL,
  `item_size` varchar(70) NOT NULL,
  `image_path` varchar(200) NOT NULL,
  `date_added` int(11) NOT NULL,
  `shopper_id` int(11) NOT NULL,
  `ip_address` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `store_basket`
--

INSERT INTO `store_basket` (`id`, `session_id`, `item_title`, `price`, `tax`, `item_id`, `item_qty`, `item_color`, `item_size`, `image_path`, `date_added`, `shopper_id`, `ip_address`) VALUES
(24, '5d7d47530560b7d30797286f1c054b26cc0a62b2', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 3, '0', '0', 'medical-supplies/misg273ki.jpg', 1515457083, 0, '::1'),
(25, '5d7d47530560b7d30797286f1c054b26cc0a62b2', 'Kole Soft Cloth Bath Pillow with Suction Cups', '9.99', '0.00', 82, 1, '0', '0', 'medical-supplies/os342.jpg', 1515450392, 0, '::1'),
(26, '5d7d47530560b7d30797286f1c054b26cc0a62b2', ' Perfit ACE Rigid Cervical Collar Adult Adjustable ', '13.45', '0.00', 45, 4, '0', '0', 'medical-supplies/pc10004bom.jpg', 1515457323, 0, '::1'),
(27, 'f03fe128a7cd9d32db8a79101e24115e4548fce0', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1515540227, 0, '::1'),
(28, '2c1c77102b22f105864b7b1df860ec7295fdd581', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1515596353, 1, '::1'),
(29, '354fd794c230c83e452df9e194db1e95b605cf88', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1515622430, 1, '::1'),
(32, '88e4e316429bf14ab69dee2c1f77fedb64ea9868', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1515710419, 3, '::1'),
(33, 'a5ab9d4699435acf3969e61453894d7c1f5348b9', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1515711455, 3, '::1'),
(34, '8dd8d400cc87ad435869d970a6791b4b737e6041', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1515797996, 3, '::1'),
(38, '0bfd38bfa442f229029a57203917ae6527e26d85', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1515871548, 3, '::1'),
(39, '0bfd38bfa442f229029a57203917ae6527e26d85', 'Invacare IClass All-In-One Commode (Single Pack) - 30\" H x 21\" W x 18\" D', '37.45', '0.00', 39, 2, '0', '0', 'medical-supplies/9630-1.jpg', 1515871559, 3, '::1'),
(40, '2e0f51e9776cea7f1d7f84fc4d174128449f884c', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1515885746, 3, '::1'),
(41, '2e0f51e9776cea7f1d7f84fc4d174128449f884c', 'Invacare IClass All-In-One Commode (Single Pack) - 30\" H x 21\" W x 18\" D', '37.45', '0.00', 41, 2, '0', '0', 'medical-supplies/9630-1.jpg', 1515885758, 3, '::1'),
(42, '3a1bf8c585c87122395c5bae1b51714e570269c9', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1515890293, 3, '::1'),
(62, '8ac6221968d020a8a377fdca147cb72da4f04b14', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 7, '0', '0', 'medical-supplies/misg273ki.jpg', 1515908994, 3, '::1'),
(69, 'c7fdb93cb0cc609c07aa76799eb0aac45abb0a9b', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 14, '0', '0', 'medical-supplies/misg273ki.jpg', 1515961509, 3, '::1'),
(70, 'c7fdb93cb0cc609c07aa76799eb0aac45abb0a9b', 'A Test product', '9.00', '0.00', 105, 5, '0', '0', 'medical-supplies/test123456.jpg', 1515962724, 3, '::1'),
(71, 'a77b4ddb6927c8b42c4cfae9b160aa67d0319bc4', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1516227006, 0, '::1'),
(72, 'de92a71c3590e43f70cb885cf49b9c555737248a', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1516242161, 0, '::1'),
(73, '2611a6db5744657805dadefc446ea8b1d8e51467', ' Suction Mount Super Grip Bath Handle', '9.99', '0.00', 103, 1, '0', '0', 'medical-supplies/misg273ki.jpg', 1516249575, 3, '::1'),
(74, '2611a6db5744657805dadefc446ea8b1d8e51467', 'Amsino International Enema Bag - 1500 mL', '1.29', '0.00', 56, 1, '0', '0', 'medical-supplies/33332700.jpg', 1516249589, 3, '::1');
