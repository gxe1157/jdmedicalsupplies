
-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `security_code` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `user_priv` int(11) NOT NULL DEFAULT '0',
  `create_date` int(11) NOT NULL,
  `modified_date` int(11) NOT NULL,
  `avatar_name` varchar(100) NOT NULL,
  `is_admin` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `last_login` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `username`, `email`, `password`, `security_code`, `status`, `user_priv`, `create_date`, `modified_date`, `avatar_name`, `is_admin`, `admin_id`, `last_login`, `is_delete`) VALUES
(1, 'evelez', 'evelio@mailers.com', '$2y$11$jekUbWMbzfOQw5ihj6skfetb994DKRT6j6hbby3Qi8QbFa5.mFYHG', '', 1, 0, 0, 0, '', 1, 0, 1508710781, 0),
(2, 'jkingsley', 'joe@mailers.com', '$2y$11$1deLrP1UtEDfby1xK9Lf1ewwVemK4rvuMiM60/B/58lYoEVJPDKnq', '', 1, 0, 0, 1507856584, '', 1, 2, 1507937365, 0);
