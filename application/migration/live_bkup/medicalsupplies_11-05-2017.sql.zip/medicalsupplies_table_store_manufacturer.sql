
-- --------------------------------------------------------

--
-- Table structure for table `store_manufacturer`
--

CREATE TABLE `store_manufacturer` (
  `id` int(11) NOT NULL,
  `company` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `email` varchar(100) NOT NULL,
  `create_date` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `store_manufacturer`
--

INSERT INTO `store_manufacturer` (`id`, `company`, `contact`, `address1`, `city`, `state`, `zip`, `phone`, `email`, `create_date`, `userid`) VALUES
(1, 'ABC', '', '123 Saddle Rd', 'Garfield', 'NJ', '07102', '9734788813', 'evelio@mailers.com', 0, 0),
(2, 'ABC', '', '123 Saddle Rd', 'Garfield', 'NJ', '07102', '9734788813', 'evelio@mailers.com', 0, 0),
(3, 'aaaaaaaaaaaaaa', '', 'aaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaa', 'aa', 'aaaaaaaaaa', '9734788813', 'evelio@mailers.com', 0, 0),
(4, 'evelio velez', 'Evelio Velez', 'address1', '', '', '', '', 'evelio@mailers.com', 0, 0);
