
-- --------------------------------------------------------

--
-- Table structure for table `store_item_assign`
--

CREATE TABLE `store_item_assign` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `webpage_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
